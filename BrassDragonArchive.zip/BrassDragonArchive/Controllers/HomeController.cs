﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BrassDragonArchive.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            

            return View();
        }

        public IActionResult PageTwo()
        {


            return View();
        }

        public IActionResult PageThree()
        {


            return View();
        }

        public IActionResult PageFour()
        {


            return View();
        }
    }
}
